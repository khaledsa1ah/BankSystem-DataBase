﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankSystem
{
    internal class SessionManager
    {
        public static string SSN { get; set; }
        public static string branchNumber { get; set; }
        public static string Name { get; set; }
        public SessionManager() 
        { 
        
        }
       

    }
}
